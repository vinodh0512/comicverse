<?php
header('Location: help_center.php');
exit;
?>
